TreeHelper for Markdown lexer.

Author: Alexey (CudaText)
License: MIT
