Plugin for CudaText.
Macros manager for CudaText. Gives commands to record/playback/save/delete/etc macros.

Config and data file:
	settings\macros.json

Author: Andrey Kvichanskiy (kvichans, at forum/github)