MASKS_IGNORE = '.rar .exe .dll .git .svn'
MASKS_ZIP = '.zip .7z .tar .gz .rar .xz .cab .deb .rpm'
MASKS_IMAGES = '.png .jpg .jpeg .gif .bmp .ico'
MASKS_BINARY = '.exe .dll .o .msi .lib .obj .pdf'
